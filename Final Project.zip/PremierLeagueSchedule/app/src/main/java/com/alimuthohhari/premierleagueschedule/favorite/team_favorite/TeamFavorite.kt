package com.alimuthohhari.premierleagueschedule.favorite.team_favorite


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import com.alimuthohhari.premierleagueschedule.club.DetailClub
import com.alimuthohhari.premierleagueschedule.R
import com.alimuthohhari.premierleagueschedule.db.database
import com.alimuthohhari.premierleagueschedule.invisible
import com.alimuthohhari.premierleagueschedule.model.Myteam
import com.alimuthohhari.premierleagueschedule.visible
import org.jetbrains.anko.*
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.select
import org.jetbrains.anko.recyclerview.v7.recyclerView
import org.jetbrains.anko.support.v4.*

class TeamFavorite : Fragment() {
    private var listMyteam: MutableList<Myteam> = mutableListOf()
    private lateinit var adapterMyTeam: MyTeamAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var imageEmpty: ImageView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return UI {
            linearLayout {
                lparams(matchParent, wrapContent) {
                    bottomMargin = dip(5)
                }
                swipeRefresh = swipeRefreshLayout {
                    setColorSchemeResources(
                        R.color.colorAccent,
                        android.R.color.holo_green_light,
                        android.R.color.holo_orange_light,
                        android.R.color.holo_red_light
                    )
                    relativeLayout {
                        lparams(wrapContent, wrapContent)

                        progressBar = progressBar {
                        }.lparams(wrapContent, wrapContent) {
                            centerInParent()
                        }
                        recyclerView = recyclerView {
                            layoutManager = LinearLayoutManager(ctx)
                        }.lparams(matchParent, wrapContent)

                    }
                }
            }

        }.view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        swipeRefresh.onRefresh {
            showMyteam()
        }
        adapterMyTeam = MyTeamAdapter(
            listMyteam,
            { partItem: Myteam -> teamClick(partItem) })
        recyclerView.adapter = adapterMyTeam

        showMyteam()
    }

    private fun showMyteam() {
        progressBar.visible()
        ctx.database.use {
            val result = select(Myteam.CLUB_TABLE)
            val team = result.parseList(classParser<Myteam>())
            listMyteam.clear()
            listMyteam.addAll(team)
            adapterMyTeam.notifyDataSetChanged()
            swipeRefresh.isRefreshing = false
            progressBar.invisible()
        }

    }

    private fun teamClick(partItem: Myteam) {
        val bundle = Bundle()
        bundle.putString("id", partItem.teamId)
        bundle.putString("badge", partItem.badgeTeam)
        bundle.putString("stadium", partItem.stadiumTeam)
        bundle.putString("name", partItem.nameTeam)
        bundle.putString("description", partItem.description)
        bundle.putString("formed", partItem.formedTeam)
        bundle.putString("thumb", partItem.stadiuThumb)
        startActivity<DetailClub>(DetailClub.POSITIONEXTRA to bundle)
    }

    override fun onResume() {
        super.onResume()
        listMyteam.clear()
        showMyteam()
    }

}

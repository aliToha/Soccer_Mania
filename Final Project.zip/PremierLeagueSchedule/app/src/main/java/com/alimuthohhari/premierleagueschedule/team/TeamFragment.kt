package com.alimuthohhari.premierleagueschedule.team


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.GridLayoutManager
import android.view.*
import android.widget.AdapterView
import com.alimuthohhari.premierleagueschedule.club.DetailClub
import com.alimuthohhari.premierleagueschedule.R
import com.alimuthohhari.premierleagueschedule.main.SpinnerAdapter
import com.alimuthohhari.premierleagueschedule.api.ApiRepo
import com.alimuthohhari.premierleagueschedule.invisible
import com.alimuthohhari.premierleagueschedule.model.League
import com.alimuthohhari.premierleagueschedule.model.Team
import com.alimuthohhari.premierleagueschedule.visible
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_team.*
import org.jetbrains.anko.support.v4.onRefresh
import org.jetbrains.anko.support.v4.startActivity

class TeamFragment : Fragment(), TeamView {

    private var team: MutableList<Team.TeamList> = mutableListOf()
    private var listLeague: MutableList<League.LeagueList> = mutableListOf()
    private lateinit var adapterSpinner: SpinnerAdapter
    private lateinit var presenter: TeamPresenter
    private lateinit var adapter: TeamAdapter
    private lateinit var leagueName: String


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_team, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        swipe_club.onRefresh {
            presenter.getTeamList(leagueName)
        }
        list_club.layoutManager = GridLayoutManager(context, 3)

        adapter = TeamAdapter(
            team,
            { partItem: Team.TeamList -> partItemClick(partItem) })
        list_club.adapter = adapter
        val request = ApiRepo()
        val gson = Gson()

        presenter = TeamPresenter(this@TeamFragment, request, gson)
        presenter.getLeague()

        adapterSpinner = SpinnerAdapter(context!!, listLeague)
        spinner_league.adapter = adapterSpinner
        spinner_league.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                leagueName = adapterSpinner.getItem(position).idLeague
                presenter.getTeamList(leagueName)
            }

        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.main_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)

    }

    private fun partItemClick(partItem: Team.TeamList) {
        val bundle = Bundle()
        bundle.putString("id", partItem.idTeam)
        bundle.putString("badge", partItem.strTeamBadge)
        bundle.putString("stadium", partItem.strStadium)
        bundle.putString("name", partItem.strTeam)
        bundle.putString("description", partItem.strDescriptionEN)
        bundle.putString("formed", partItem.intFormedYear.toString())
        bundle.putString("thumb", partItem.strStadiumThumb)
        startActivity<DetailClub>(DetailClub.POSITIONEXTRA to bundle)
    }

    override fun showLoading() {
        progress_club.visible()
        list_club.invisible()
    }

    override fun hideLoading() {
        progress_club.invisible()
        list_club.visible()
    }

    override fun showLeague(data: List<League.LeagueList>) {
        listLeague.clear()
        listLeague.addAll(data)
        adapterSpinner.notifyDataSetChanged()
    }

    override fun showTeamList(data: List<Team.TeamList>) {
        swipe_club.isRefreshing = false
        team.clear()
        team.addAll(data)
        adapter.notifyDataSetChanged()
    }

}

package com.alimuthohhari.premierleagueschedule.detail_event

import com.alimuthohhari.premierleagueschedule.api.ApiInterface
import com.alimuthohhari.premierleagueschedule.api.ApiRepo
import com.alimuthohhari.premierleagueschedule.model.Events
import com.alimuthohhari.premierleagueschedule.model.Team
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class EventDetailPresenter
    (
    private val view: DetailView,
    private val apiRepository: ApiRepo,
    private val gson: Gson
) {


    fun getBadgeHome(idHome: String?) {
        doAsync {
            val data = gson.fromJson(
                apiRepository
                    .doRequest(ApiInterface.getBadge(idHome)),
                Team::class.java
            )
            uiThread {
                view.showHomeBadge(data.listTeam)
            }
        }
    }

    fun getBadgeAway(idAway: String?) {
        doAsync {
            val data = gson.fromJson(
                apiRepository
                    .doRequest(ApiInterface.getBadge(idAway)),
                Team::class.java
            )
            uiThread {
                view.showAwayBadge(data.listTeam)
            }
        }
    }

    fun getDetail(idEvent: String?) {
        doAsync {
            val data = gson.fromJson(
                apiRepository
                    .doRequest(ApiInterface.getDetail(idEvent)),
                Events::class.java
            )
            uiThread {
                view.hideLoading()
                view.showDetail(data.listEvents)
            }
        }
    }
}

package com.alimuthohhari.premierleagueschedule.favorite.match_favorite


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import com.alimuthohhari.premierleagueschedule.R
import com.alimuthohhari.premierleagueschedule.db.database
import com.alimuthohhari.premierleagueschedule.detail_event.DetailEvent
import com.alimuthohhari.premierleagueschedule.invisible
import com.alimuthohhari.premierleagueschedule.model.Schedule
import com.alimuthohhari.premierleagueschedule.visible
import org.jetbrains.anko.*
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.select
import org.jetbrains.anko.recyclerview.v7.recyclerView
import org.jetbrains.anko.support.v4.*

class MatchFavorite : Fragment() {
    private var listMatch: MutableList<Schedule> = mutableListOf()
    private lateinit var adapterMatchMy: MyScheduleAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var imageEmpty: ImageView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return UI {
            linearLayout {
                lparams(matchParent, wrapContent) {
                    bottomMargin = dip(5)
                }
                swipeRefresh = swipeRefreshLayout {
                    setColorSchemeResources(
                        R.color.colorAccent,
                        android.R.color.holo_green_light,
                        android.R.color.holo_orange_light,
                        android.R.color.holo_red_light
                    )
                    relativeLayout {
                        lparams(wrapContent, wrapContent)

                        progressBar = progressBar {
                        }.lparams(wrapContent, wrapContent) {
                            centerInParent()
                        }
                        recyclerView = recyclerView {
                            layoutManager = LinearLayoutManager(ctx)
                        }.lparams(matchParent, wrapContent)

                    }
                }
            }

        }.view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        swipeRefresh.onRefresh {
            showSchedule()
        }
        adapterMatchMy = MyScheduleAdapter(
            listMatch,
            { partItem: Schedule -> schedulClick(partItem) })
        recyclerView.adapter = adapterMatchMy
        showSchedule()
    }

    private fun showSchedule() {
        progressBar.visible()
        ctx.database.use {
            val result = select(Schedule.TABLE_SCHEDULE)
            val schedule = result.parseList(classParser<Schedule>())
            listMatch.clear()
            listMatch.addAll(schedule)
            adapterMatchMy.notifyDataSetChanged()
            swipeRefresh.isRefreshing = false
            progressBar.invisible()
        }

    }

    private fun schedulClick(partItem: Schedule) {
        val bundle = Bundle()
        bundle.putString("id", partItem.scheduleId)
        bundle.putString("idHome", partItem.teamHome)
        bundle.putString("idAway", partItem.teamAway)
        startActivity<DetailEvent>(DetailEvent.EXTRADATA to bundle)
    }

    override fun onResume() {
        super.onResume()
        listMatch.clear()
        showSchedule()
    }

}

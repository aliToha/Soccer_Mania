package com.alimuthohhari.premierleagueschedule.search

import com.alimuthohhari.premierleagueschedule.api.ApiInterface
import com.alimuthohhari.premierleagueschedule.api.ApiRepo
import com.alimuthohhari.premierleagueschedule.helper.CoroutineContextProvider
import com.alimuthohhari.premierleagueschedule.helper.EspressoIdlingResource
import com.alimuthohhari.premierleagueschedule.model.EventsSearch
import com.alimuthohhari.premierleagueschedule.model.Players
import com.alimuthohhari.premierleagueschedule.model.Team
import com.google.gson.Gson
import kotlinx.coroutines.experimental.async
import org.jetbrains.anko.coroutines.experimental.bg

class SearchPresenter(
    private val view: FindView,
    private val apiRepository: ApiRepo,
    private val gson: Gson,
    private val context: CoroutineContextProvider = CoroutineContextProvider()
) {
    fun getMatchList(search: String) {
        EspressoIdlingResource.increment()
        view.showLoading()
        async(context.main) {
            val data = bg {
                gson.fromJson(
                    apiRepository
                        .doRequest(ApiInterface.getMatch(search)),
                    EventsSearch::class.java
                )
            }
            view.hideLoading()
            view.showMatch(data.await().listEvents)

        }
        if (!EspressoIdlingResource.idlingResource.isIdleNow) {
            EspressoIdlingResource.decrement()
        }
    }

    fun getTeamList(search: String) {
        EspressoIdlingResource.increment()
        view.showLoading()
        async(context.main) {
            val data = bg {
                gson.fromJson(
                    apiRepository
                        .doRequest(ApiInterface.getClub(search)),
                    Team::class.java
                )
            }
            view.showTeam(data.await().listTeam)
            view.hideLoading()
        }
        if (!EspressoIdlingResource.idlingResource.isIdleNow) {
            EspressoIdlingResource.decrement()
        }
    }

    fun getPlayerList(search: String) {
        EspressoIdlingResource.increment()
        view.showLoading()
        async(context.main) {
            val data = bg {
                gson.fromJson(
                    apiRepository
                        .doRequest(ApiInterface.getPlayers(search)),
                    Players::class.java
                )
            }
            view.hideLoading()
            view.showPlayer(data.await().playerList)

        }
        if (!EspressoIdlingResource.idlingResource.isIdleNow) {
            EspressoIdlingResource.decrement()
        }
    }
}
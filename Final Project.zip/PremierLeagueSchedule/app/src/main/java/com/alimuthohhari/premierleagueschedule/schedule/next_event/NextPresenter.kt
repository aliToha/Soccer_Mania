package com.alimuthohhari.premierleagueschedule.schedule.next_event

import com.alimuthohhari.premierleagueschedule.api.ApiInterface
import com.alimuthohhari.premierleagueschedule.api.ApiRepo
import com.alimuthohhari.premierleagueschedule.helper.CoroutineContextProvider
import com.alimuthohhari.premierleagueschedule.helper.EspressoIdlingResource
import com.alimuthohhari.premierleagueschedule.model.Events
import com.alimuthohhari.premierleagueschedule.model.League
import com.google.gson.Gson
import kotlinx.coroutines.experimental.async
import org.jetbrains.anko.coroutines.experimental.bg

class NextPresenter(
    private val view: NextView,
    private val apiRepository: ApiRepo,
    private val gson: Gson,
    private val context: CoroutineContextProvider = CoroutineContextProvider()
) {
    fun getLeague() {
        EspressoIdlingResource.increment()
        view.showLoading()
        async(context.main) {
            val data = bg {
                gson.fromJson(
                    apiRepository
                        .doRequest(ApiInterface.getLeague()),
                    League::class.java
                )
            }
            view.showLeague(data.await().leaguesList)
        }
        if (!EspressoIdlingResource.idlingResource.isIdleNow) {
            EspressoIdlingResource.decrement()
        }
    }

    fun getEventNext(idLeague: String?) {
        EspressoIdlingResource.increment()
        view.showLoading()
        async(context.main) {
            val data = bg {
                gson.fromJson(
                    apiRepository
                        .doRequest(ApiInterface.getEventsNext(idLeague)),
                    Events::class.java
                )
            }
            view.showMatchNext(data.await().listEvents)
            view.hideLoading()
        }
        if (!EspressoIdlingResource.idlingResource.isIdleNow) {
            EspressoIdlingResource.decrement()
        }
    }

}
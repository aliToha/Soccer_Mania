package com.alimuthohhari.premierleagueschedule.standing

import com.alimuthohhari.premierleagueschedule.api.ApiInterface
import com.alimuthohhari.premierleagueschedule.api.ApiRepo
import com.alimuthohhari.premierleagueschedule.helper.CoroutineContextProvider
import com.alimuthohhari.premierleagueschedule.helper.EspressoIdlingResource
import com.alimuthohhari.premierleagueschedule.model.League
import com.alimuthohhari.premierleagueschedule.model.Season
import com.alimuthohhari.premierleagueschedule.model.Standing
import com.google.gson.Gson
import kotlinx.coroutines.experimental.async
import org.jetbrains.anko.coroutines.experimental.bg

class StandingPresenter
    (
    private val view: StandingView,
    private val apiRepository: ApiRepo,
    private val gson: Gson,
    private val context: CoroutineContextProvider = CoroutineContextProvider()
) {
    fun getLeagueList() {
        EspressoIdlingResource.increment()
        view.showLoading()
        async(context.main) {
            val data = bg {
                gson.fromJson(
                    apiRepository
                        .doRequest(ApiInterface.getLeague()),
                    League::class.java
                )
            }
            view.showLeagueList(data.await().leaguesList)
            view.hideLoading()
        }
        if (!EspressoIdlingResource.idlingResource.isIdleNow) {
            EspressoIdlingResource.decrement()
        }
    }

    fun getStandingList(league: String, season: String) {
        EspressoIdlingResource.increment()
        view.showLoading()
        async(context.main) {
            val data = bg {
                gson.fromJson(
                    apiRepository
                        .doRequest(ApiInterface.getStanding(league, season)),
                    Standing::class.java
                )
            }
            view.showStandingList(data.await().standingList)
            view.hideLoading()
        }
        if (!EspressoIdlingResource.idlingResource.isIdleNow) {
            EspressoIdlingResource.decrement()
        }
    }

    fun getSeasonList(league: String) {
        EspressoIdlingResource.increment()
        view.showLoading()
        async(context.main) {
            val data = bg {
                gson.fromJson(
                    apiRepository
                        .doRequest(ApiInterface.getSeason(league)),
                    Season::class.java
                )
            }
            view.showSeasonList(data.await().seasonsList)
        }
        if (!EspressoIdlingResource.idlingResource.isIdleNow) {
            EspressoIdlingResource.decrement()
        }
    }

}


package com.alimuthohhari.premierleagueschedule.schedule.last_event

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ProgressBar
import android.widget.Spinner
import com.alimuthohhari.premierleagueschedule.R
import com.alimuthohhari.premierleagueschedule.main.SpinnerAdapter
import com.alimuthohhari.premierleagueschedule.api.ApiRepo
import com.alimuthohhari.premierleagueschedule.detail_event.DetailEvent
import com.alimuthohhari.premierleagueschedule.invisible
import com.alimuthohhari.premierleagueschedule.model.League
import com.alimuthohhari.premierleagueschedule.model.ListEvents
import com.alimuthohhari.premierleagueschedule.visible
import com.google.gson.Gson
import org.jetbrains.anko.*
import org.jetbrains.anko.recyclerview.v7.recyclerView
import org.jetbrains.anko.support.v4.*

class LastEventFragment : Fragment(), LastView {

    private var listNext: MutableList<ListEvents> = mutableListOf()
    private var listLeague: MutableList<League.LeagueList> = mutableListOf()
    private lateinit var adapterNext: LastEventsAdapter
    private lateinit var adapterSpinner: SpinnerAdapter
    private lateinit var presenter: LastPresenter
    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var spinner: Spinner
    private var league = String()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return UI {
            linearLayout {
                lparams(matchParent, wrapContent) {
                    bottomMargin = dip(5)
                }
                swipeRefresh = swipeRefreshLayout {
                    setColorSchemeResources(
                        R.color.colorAccent,
                        android.R.color.holo_green_light,
                        android.R.color.holo_orange_light,
                        android.R.color.holo_red_light
                    )
                    relativeLayout {
                        lparams(matchParent, wrapContent)
                        spinner = spinner {
                            id = R.id.spinner_league
                        }.lparams(wrapContent, wrapContent) {
                            centerHorizontally()
                            alignParentTop()
                        }
                        progressBar = progressBar {
                        }.lparams(wrapContent, wrapContent) {
                            centerInParent()
                        }
                        recyclerView = recyclerView {
                            layoutManager = LinearLayoutManager(ctx)
                        }.lparams(matchParent, wrapContent) {
                            topMargin = dip(50)
                            below(R.id.spiner_league)
                        }

                    }
                }
            }

        }.view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        val request = ApiRepo()
        val gson = Gson()

        swipeRefresh.onRefresh {
            listNext.clear()
            presenter.getEventLast(league)
        }
        adapterSpinner = SpinnerAdapter(ctx, listLeague)
        spinner.adapter = adapterSpinner

        adapterNext = LastEventsAdapter(
            listNext,
            { partItem: ListEvents -> itemClick(partItem) })
        recyclerView.adapter = adapterNext

        presenter = LastPresenter(this, request, gson)
        presenter.getLeague()

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                league = adapterSpinner.getItem(position).idLeague
                presenter.getEventLast(league)
            }

        }

    }

    private fun itemClick(partItem: ListEvents) {
        val bundle = Bundle()
        bundle.putString("id", partItem.idEvent)
        bundle.putString("idHome", partItem.idHomeTeam)
        bundle.putString("idAway", partItem.idAwayTeam)
        startActivity<DetailEvent>(DetailEvent.EXTRADATA to bundle)
    }

    override fun showLoading() {
        progressBar.visible()
        recyclerView.invisible()
    }

    override fun hideLoading() {
        progressBar.invisible()
        recyclerView.visible()
    }

    override fun showMatchLast(data: List<ListEvents>) {
        swipeRefresh.isRefreshing = false
        listNext.clear()
        listNext.addAll(data)
        adapterNext.notifyDataSetChanged()
    }

    override fun showLeague(data: List<League.LeagueList>) {
        listLeague.clear()
        listLeague.addAll(data)
        adapterSpinner.notifyDataSetChanged()
    }

}
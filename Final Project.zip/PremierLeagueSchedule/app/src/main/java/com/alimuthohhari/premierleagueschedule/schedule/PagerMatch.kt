package com.alimuthohhari.premierleagueschedule.schedule

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import com.alimuthohhari.premierleagueschedule.schedule.last_event.LastEventFragment
import com.alimuthohhari.premierleagueschedule.schedule.next_event.NextEventFragment

class PagerMatch(fm: FragmentManager?) : FragmentPagerAdapter(fm) {

    override fun getItem(position: Int): Fragment {
        var fragment = Fragment()
        when (position) {
            0 -> fragment = NextEventFragment()
            1 -> fragment = LastEventFragment()
        }
        return fragment
    }

    override fun getCount(): Int {
        return 2
    }

    override fun getPageTitle(position: Int): CharSequence? {
        var title = String()
        when (position) {
            0 -> title = "NEXT EVENT"
            1 -> title = "LAST EVENT"
        }
        return title
    }
}